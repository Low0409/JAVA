import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalcServlet
 */
@WebServlet("/calc")
public class CalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public CalcServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String strx =request.getParameter("x");
		String stry =request.getParameter("y");
		int x = Integer.parseInt(strx);
		int y = Integer.parseInt(stry);
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=utf-8>");
		out.println("</head>");
		out.println("<body>");
		out.println("<table border=\"5\" frame=\"void\">");
		out.println("<tr>");
		out.println("<th>加</th>");
		out.println("<th>"+(x+y)+"</th>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>減</th>");
		out.println("<th>"+(x-y)+"</th>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>乗</th>");
		out.println("<th>"+(x*y)+"</th>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>除</th>");
		out.println("<th>"+(x/y)+"</th>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</body>");
		out.println("</html>");

	
	}

}
